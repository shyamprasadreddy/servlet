package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;



import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
	}

	public void destroy() {
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String mobileNo=request.getParameter("mobileNo");
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");                      
		String confirmPassword=request.getParameter("confirmPassword");
		String gender=request.getParameter("gender");                                                   
		String [] communication=request.getParameterValues("communication");

		String graduation=request.getParameter("graduation");
		String resume=request.getParameter("resume");
		String description=request.getParameter("description");


		out.println("<html>");
		out.println("<head>");
		out.println("</head>");
		out.println("<body>");
		out.println("<h1><font color='green'>First Name=</font>"+firstName);
		out.println("<h1><font color='green'>Last Name=</font>"+lastName);
		out.println("<h1><font color='green'>EmailId=</font>"+emailId);
		out.println("<h1><font color='green'>Mobile Number=</font>"+mobileNo);                           
		out.println("<h1><font color='green'>User Name=</font>"+userName);
		out.println("<h1><font color='green'>Password=</font>"+password);
		out.println("<h1><font color='green'>Confirm Password=</font>"+confirmPassword);
		out.println("<h1><font color='green'>Gender=</font>"+gender);

			out.println("<h1><font color='black'>Communications=</font>");
			for (String string : communication) {
				out.println("\n"+string);
			}
		
		out.println("<h1><font color='green'>Graduation=</font>"+graduation);
		out.println("<h1><font color='olive'>ResumeUploaded=</font>"+resume);
		out.println("<h1><font color='green'>Description=</font>"+description);
		out.println("</body>");
		out.println("</html>");
	}

}