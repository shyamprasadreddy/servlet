package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/LoginServlet2")
public class LoginServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private Connection con;
	public void init() {
		ServletContext servletContext=getServletContext();
		con=(Connection) servletContext.getAttribute("con");
	}

	public void destroy() {
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			//PrintWriter out=response.getWriter();
			RequestDispatcher dispatcher;
			String userName=request.getParameter("userName");
			String password=request.getParameter("password");
			UserBean userBean=new UserBean(userName,password);
			PreparedStatement ps1=con.prepareStatement("select password from userbean where userName=?");
			ps1.setString(1, userBean.getUserName());
			ResultSet rs=ps1.executeQuery();
			if(rs.next()) {
				if(rs.getString("password").equals(userBean.getPassword())) {
					//			System.out.println("entered success");
					dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
					request.setAttribute("userBean", userBean);
					dispatcher.forward(request, response);
				}
				else {
					dispatcher=request.getRequestDispatcher("ErrorPage.jsp");
					request.setAttribute("erroMessage", "Invalid password");
					dispatcher.forward(request, response);
				}
			}
			else {
				dispatcher=request.getRequestDispatcher("ErrorPage.jsp");
				request.setAttribute("erroMessage", "Invalid user and password");
				dispatcher.forward(request, response);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
