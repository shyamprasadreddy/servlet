package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/LoginServlet1")
public class LoginServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public void init(ServletConfig config) throws ServletException {
	}


	public void destroy() {
	}
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		RequestDispatcher dispatcher;
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		UserBean userBean=new UserBean(userName,password);
		
		if (userBean.getUserName().equals("shyam")&&userBean.getPassword().equals("hello")) {			
			dispatcher=request.getRequestDispatcher("SuccessServlet");
			request.setAttribute("userBean", userBean);
			dispatcher.forward(request, response);
			int hi=response.getStatus();
			out.println(hi);
			
		} else {
			dispatcher=request.getRequestDispatcher("ErrorServlet");
			request.setAttribute("error Message", "Invalid userId or Password");
			dispatcher.forward(request, response);
		}
	}

}
